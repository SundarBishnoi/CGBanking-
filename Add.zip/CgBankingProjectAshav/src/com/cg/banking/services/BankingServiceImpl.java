package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.User;
import com.cg.banking.daoservices.BankingDAO;
import com.cg.banking.daoservices.BankingDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServiceImpl implements BankingService{
	@SuppressWarnings("rawtypes")
	private BankingDAO bankingDao=new BankingDAOImpl();
	@Override
	public long openAccount(String customerName,String emailId, String address,String pancard,String accountType,float accountBalance,String securityAnswer)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		
		int  randomNumber=(int) ((Math.random()*((9999-1000)+1))+1000);
		String fixedString="Abcd";
		String loginPassword=fixedString+randomNumber;
		
		randomNumber=(int) ((Math.random()*((9999-1000)+1))+1000);
		String pinNumber=""+randomNumber;
		
		Customer customer=new Customer(customerName,emailId,address,pancard,new User(loginPassword,securityAnswer,pinNumber));
		
		Account account=new Account(accountType,accountBalance,customer);
		List<Account> listAccount=new ArrayList<Account>();
		listAccount.add(account);
		customer.setAccounts(listAccount);
		
		Transaction transaction=new Transaction(accountBalance,"credit",account);
		List<Transaction> listTransaction=new ArrayList<Transaction>();
		listTransaction.add(transaction);
		account.setTransaction(listTransaction);
		
		customer=bankingDao.save(customer);
		
		return account.getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo,float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException {
	
				Account account=bankingDao.findAccountNo(accountNo);
				
				//if(customer==null)
					//throw new AccountNotFoundException();
				System.out.println(account.getAccountNo());
				bankingDao.update(accountNo,account.getAccountBalance()+amount);
				
				Transaction transaction=new Transaction();
				transaction.setAccount(account);
				transaction.setAmount(amount);
				transaction.setTransactionType("credit");
				bankingDao.save(transaction);
				return 0;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account=bankingDao.findAccountNo(accountNo);
		
		//if(customer==null)
			//throw new AccountNotFoundException();
		System.out.println(account.getAccountNo());
		bankingDao.update(accountNo,account.getAccountBalance()-amount);
		
		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setAmount(amount);
		transaction.setTransactionType("debit");
		bankingDao.save(transaction);
		return 0;
	}

	@Override
	public boolean fundTransfer(String accountNoTo, String accountNoFrom,
			float transferAmount)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		//Customer customerAccount1=bankingDao.findAccountNo(accountNoTo);
		//if(customerAccount1==null)
			//throw new AccountNotFoundException();
		//Customer customerAccount2=bankingDao.findAccountNo(accountNoFrom);
		//if(customerAccount2==null)
			throw new AccountNotFoundException();
		//if(customerAccount1.getAccount().getAccountBalance()<transferAmount)
			//throw new InsufficientAmountException();
		//withdrawAmount(accountNoFrom, transferAmount);
		//depositAmount(accountNoTo, transferAmount);
		
		//return false;
	}

	@Override
	public Customer getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		Account account=bankingDao.findAccountNo(accountNo);
		return null;
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
		List<Account> accountList=new ArrayList<Account>();
		accountList=bankingDao.findAllAccountDetails();
		return accountList;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transactionList=new ArrayList<Transaction>();
		transactionList=bankingDao.getTransactions(accountNo);
		return transactionList;
	}

	@Override
	public List<Transaction> getAllTransactionDetails()
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> accountList=new ArrayList<Transaction>();
		accountList=bankingDao.findAllTransactionDetails();
		return accountList;
	}	
}