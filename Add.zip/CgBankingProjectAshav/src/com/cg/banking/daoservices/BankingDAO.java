package com.cg.banking.daoservices;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public interface BankingDAO{
	Customer save(Customer customer);
	Account findAccountNo(long accountNo);
	void update(long accountNo, float amount);
	
	
	Account save(Account account);
	Transaction save(Transaction transaction);
	
	
	List<Account> findAllAccountDetails();
	List<Transaction> getTransactions(long accountNo);
	List<Transaction> findAllTransactionDetails();
	long findAccountNo1(long id);
}
