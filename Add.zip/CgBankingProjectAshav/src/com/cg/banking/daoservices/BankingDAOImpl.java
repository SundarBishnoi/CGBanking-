package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public class BankingDAOImpl implements BankingDAO{
	EntityManagerFactory factory1=Persistence.createEntityManagerFactory("JPA-PU");
	
	@Override
	public Customer save(Customer customer) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);																				//Data to be saved into the table of database..
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer;
	}
	@Override
	public Account save(Account account) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);																				//Data to be saved into the table of database..
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}
	@Override
	public Transaction save(Transaction transaction) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);																				//Data to be saved into the table of database..
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}
	@Override
	public Account findAccountNo(long accountNo) {
		EntityManager entityManager=factory1.createEntityManager();
		return entityManager.find(Account.class,accountNo);
	}
	@Override
	public void update(long accountNo, float amount){
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		Account account=entityManager.find(Account.class, accountNo);
		account.setAccountBalance(amount);
		entityManager.getTransaction().commit();
	}
	
	@Override
	public long findAccountNo1(long id) {
		EntityManager entityManager=factory1.createEntityManager();
		//List<Customer_Account> listPersons = entityManager.createQuery("SELECT c_a FROM Customer_Account c_a WHERE  customer_customerid="+id).getResultList();
		//long aId =(long) entityManager.Query("SELECT c FROM Customer c where pinNumber="+pinNumber);
		//Customer customer=entityManager.find(Customer.class, pinNumber);
		List<Account> listPersons = entityManager.createQuery("SELECT c FROM Account c WHERE  customer_customerid="+id).getResultList();
		long aid=0;
		for(Account cust:listPersons)
				aid=cust.getAccountNo();
		return id;
	}
	
	@Override
	public List<Account> findAllAccountDetails() {
		EntityManager entityManager=factory1.createEntityManager();
		//Query query=entityManager.createQuery("getAllAccount");                                                //complete data to be fetch from table Associate
		//List<Account> list=query.getResultList();
		entityManager.getTransaction().begin();
	    List<Account> listPersons = entityManager.createQuery("SELECT a FROM Account a").getResultList();
	    entityManager.getTransaction().commit();
		return listPersons;
	}
	@Override
	public List getTransactions(long accountNo) {
		EntityManager entityManager=factory1.createEntityManager();
		//Query query=entityManager.createQuery("getAllAccount");                                                //complete data to be fetch from table Associate
		//List<Account> list=query.getResultList();
		entityManager.getTransaction().begin();
	    List<Transaction> listPersons = entityManager.createQuery("SELECT t FROM Transaction t where accountno="+accountNo).getResultList();
	    entityManager.getTransaction().commit();
		return listPersons;
	}
	@Override
	public List<Transaction> findAllTransactionDetails() {
		EntityManager entityManager=factory1.createEntityManager();
		//Query query=entityManager.createQuery("getAllAccount");                                                //complete data to be fetch from table Associate
		//List<Account> list=query.getResultList();
		entityManager.getTransaction().begin();
	    List<Transaction> listPersons = entityManager.createQuery("SELECT t FROM Transaction  t").getResultList();
	    entityManager.getTransaction().commit();
		return listPersons;
	}
}