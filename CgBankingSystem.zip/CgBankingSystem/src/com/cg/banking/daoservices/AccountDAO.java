package com.cg.banking.daoservices;

public interface AccountDAO {
	long saveAccountOpen(String accountType, float initBalance);
}